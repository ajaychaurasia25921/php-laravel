<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProvisionRate extends Model
{
    protected $table = "provision_rates";

    public $timestamps = false;

}
